"""Start the local-only FlowLens app. No remote deployment or AI calls at startup."""
import uvicorn
if __name__ == '__main__':
    uvicorn.run('app.main:app',host='127.0.0.1',port=8000)
